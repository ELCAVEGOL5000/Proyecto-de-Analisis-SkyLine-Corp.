<?php
session_start();
include 'config.php';

$id = $_GET['id'] ?? null;
$nombre = $stock = $imagen = '';
$precio = 0.00;  // nuevo campo

// Obtener datos si se está editando
if ($id) {
    $res = $conn->query("SELECT * FROM productos WHERE id=$id");
    if ($res && $row = $res->fetch_assoc()) {
        $nombre = $row['nombre'];
        $stock = $row['stock'];
        $imagen = $row['imagen'];
        $precio = $row['precio'];  // nuevo campo
    }
}

// Procesar formulario
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = $_POST['nombre'];
    $stock = $_POST['stock'];
    $precio = $_POST['precio']; // nuevo

    // Subida de imagen
    if (isset($_FILES['imagen']) && $_FILES['imagen']['name']) {
        $uploads_dir = 'uploads/';
        
        if (!is_dir($uploads_dir)) {
            mkdir($uploads_dir, 0777, true);
        }

        $filename = basename($_FILES['imagen']['name']);
        $target = $uploads_dir . $filename;

        if ($_FILES['imagen']['error'] !== UPLOAD_ERR_OK) {
            echo "<p style='color:red;'>⚠️ Error al subir la imagen (código: " . $_FILES['imagen']['error'] . ")</p>";
        } elseif (move_uploaded_file($_FILES['imagen']['tmp_name'], $target)) {
            $imagen = $target;
            echo "<p style='color:green;'>✅ Imagen subida correctamente.</p>";
        } else {
            echo "<p style='color:red;'>❌ Error al mover el archivo. Verifica los permisos de la carpeta 'uploads/'.</p>";
        }
    }

    // Guardar o actualizar en la base de datos
    if ($id) {
        $stmt = $conn->prepare("UPDATE productos SET nombre=?, stock=?, imagen=?, precio=? WHERE id=?");
        $stmt->bind_param("sisdi", $nombre, $stock, $imagen, $precio, $id);
    } else {
        $stmt = $conn->prepare("INSERT INTO productos (nombre, stock, imagen, precio) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("sisd", $nombre, $stock, $imagen, $precio);
    }

    $stmt->execute();
    header("Location: inventario.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?= $id ? "Editar" : "Nuevo" ?> producto</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #f0f0f0;
        }
        h1 {
            color: #333;
        }
        form {
            background: white;
            padding: 20px;
            max-width: 450px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"] {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #218838;
        }
        img {
            margin-top: 10px;
            max-width: 120px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <h1><?= $id ? "Editar" : "Nuevo" ?> producto</h1>

    <form method="post" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label>
        <input type="text" name="nombre" id="nombre" value="<?= htmlspecialchars($nombre) ?>" required>

        <label for="stock">Stock:</label>
        <input type="number" name="stock" id="stock" value="<?= htmlspecialchars($stock) ?>" required>

        <label for="precio">Precio:</label>
        <input type="number" step="0.01" min="0" name="precio" id="precio" value="<?= htmlspecialchars($precio) ?>" required>

        <label for="imagen">Imagen:</label>
        <input type="file" name="imagen" id="imagen" accept="image/*">

        <?php if ($imagen): ?>
            <img src="<?= htmlspecialchars($imagen) ?>" alt="Imagen del producto">
        <?php endif; ?>

        <br><br>
        <button type="submit">Guardar</button>
    </form>
</body>
</html>
