<?php
session_start();
include 'config.php';

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

// Mensaje para el usuario
$mensaje = $_SESSION['mensaje'] ?? '';
unset($_SESSION['mensaje']);

// Agregar kit al carrito con cantidad (ajusta según lógica que quieras)
// Aquí asumo que agregas kits completos, no productos individuales

if (isset($_GET['agregar_kit'])) {
    $id = intval($_GET['agregar_kit']);
    $cantidad = intval($_GET['cantidad'] ?? 1);
    if ($cantidad < 1) $cantidad = 1;

    // Obtener kit info y productos incluidos
    $stmt = $conn->prepare("SELECT * FROM kits WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $kitRes = $stmt->get_result();

    if ($kit = $kitRes->fetch_assoc()) {
        // Aquí podrías agregar comprobaciones de stock si quieres, pero kits suelen manejar stock diferente
        $kit_id = $kit['id'];
        $kit_nombre = $kit['nombre'];
        $kit_precio = $kit['precio'];

        $carrito_id = 'kit_'.$kit_id; // ID único para kit en carrito

        $cantidadEnCarrito = $_SESSION['carrito'][$carrito_id]['cantidad'] ?? 0;
        $nuevaCantidad = $cantidadEnCarrito + $cantidad;

        $_SESSION['carrito'][$carrito_id] = [
            'nombre' => $kit_nombre,
            'precio' => $kit_precio,
            'cantidad' => $nuevaCantidad,
            'es_kit' => true,
            'kit_id' => $kit_id
        ];
    }
    header("Location: kits.php");
    exit;
}

// Eliminar item del carrito (producto o kit)
if (isset($_POST['eliminar'])) {
    $id = $_POST['eliminar'];
    if (isset($_SESSION['carrito'][$id])) {
        unset($_SESSION['carrito'][$id]);
    }
    header("Location: kits.php");
    exit;
}

// Vaciar carrito
if (isset($_POST['vaciar'])) {
    $_SESSION['carrito'] = [];
    header("Location: kits.php");
    exit;
}

// Obtener kits
$kits = $conn->query("SELECT * FROM kits");

// Función para obtener productos de un kit
function obtenerProductosDeKit($conn, $kit_id) {
    $stmt = $conn->prepare("
        SELECT p.nombre 
        FROM kit_producto kp
        JOIN productos p ON kp.producto_id = p.id
        WHERE kp.kit_id = ?
    ");
    $stmt->bind_param("i", $kit_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $productos = [];
    while ($row = $res->fetch_assoc()) {
        $productos[] = $row['nombre'];
    }
    return $productos;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Kits disponibles</title>
  <link rel="stylesheet" href="kits.css" />
  <style>
    /* (Aquí pon tus estilos existentes para botones, carrito, productos, etc.) */
    /* ... usa los estilos que ya tienes ... */

    .kit {
      border: 1px solid #ccc;
      border-radius: 8px;
      padding: 15px;
      margin: 15px;
      max-width: 300px;
      background: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .kit h3 {
      margin-top: 0;
      color: #007bff;
    }
    .kit ul {
      list-style-type: disc;
      padding-left: 20px;
      margin-bottom: 10px;
      color: #333;
    }
    .kit p {
      font-weight: bold;
      font-size: 1.1em;
      margin-bottom: 10px;
    }
  </style>
</head>
<body>

<header style="display:flex; justify-content:space-between; align-items:center; padding:20px; background:#f0f0f0;">
    <a href="tienda_page.php" 
       style="background:#6c757d; color:#fff; padding:10px 16px; border-radius:6px; text-decoration:none; font-weight:bold;">
      ← Volver al inicio
    </a>

    <button class="carrito-btn" id="toggle-carrito" style="position: static; background:#007bff; color:#fff; border:none; padding:10px 16px; border-radius:6px; cursor:pointer; font-weight:bold;">
       Carrito
      <span class="carrito-count" style="background:#dc3545; border-radius:50%; padding:2px 8px; margin-left:6px;">
        <?= array_sum(array_column($_SESSION['carrito'], 'cantidad')) ?: 0 ?>
      </span>
    </button>
</header>

<?php if($mensaje): ?>
  <p style="max-width:900px; margin: 10px auto; color:#dc3545; font-weight:bold; text-align:center;"><?= htmlspecialchars($mensaje) ?></p>
<?php endif; ?>

<h1 style="text-align:center; margin-top:20px;">Kits disponibles</h1>

<div class="carrito-modal" id="carrito-modal">
  <h3>Tu carrito</h3>
  <?php if (!empty($_SESSION['carrito'])): ?>
    <?php $total = 0; ?>
    <?php foreach($_SESSION['carrito'] as $id => $item): ?>
      <?php $subtotal = $item['precio'] * $item['cantidad']; ?>
      <div class="carrito-item" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
        <div>
          <p style="margin:0; font-weight:bold;"><?= htmlspecialchars($item['nombre']) ?></p>
          <span>Cantidad: <?= $item['cantidad'] ?></span><br>
          <span>Precio unitario: $<?= number_format($item['precio'], 2) ?></span><br>
          <span>Subtotal: $<?= number_format($subtotal, 2) ?></span>
        </div>
        <form method="post" style="margin:0;">
          <input type="hidden" name="eliminar" value="<?= htmlspecialchars($id) ?>">
          <button type="submit" class="btn-eliminar" title="Eliminar">&times;</button>
        </form>
      </div>
      <?php $total += $subtotal; ?>
    <?php endforeach; ?>
    <p style="font-weight:bold; text-align:right; margin-top:10px;">Total: $<?= number_format($total, 2) ?></p>

    <form method="post" action="pagar.php" style="margin-bottom:10px;">
      <button type="submit" class="btn-agregar">Pagar</button>
    </form>

    <form method="post">
      <button type="submit" name="vaciar" class="btn-vaciar">Vaciar carrito</button>
    </form>
  <?php else: ?>
    <p>El carrito está vacío.</p>
  <?php endif; ?>
  <button class="cerrar-carrito" id="cerrar-carrito">Cerrar</button>
</div>

<div class="productos" style="justify-content:center;">
  <?php while ($kit = $kits->fetch_assoc()): ?>
    <?php $productosKit = obtenerProductosDeKit($conn, $kit['id']); ?>
    <div class="kit">
      <h3><?= htmlspecialchars($kit['nombre']) ?></h3>
      <p>Precio: $<?= number_format($kit['precio'], 2) ?></p>
      <strong>Productos incluidos:</strong>
      <ul>
        <?php foreach($productosKit as $prodNombre): ?>
          <li><?= htmlspecialchars($prodNombre) ?></li>
        <?php endforeach; ?>
      </ul>

      <form method="get" action="">
        <input type="hidden" name="agregar_kit" value="<?= $kit['id'] ?>">
        <input type="number" name="cantidad" value="1" min="1" style="width:60px; padding:4px; border-radius:4px; border:1px solid #ccc;" required>
        <button type="submit" class="btn-agregar">Agregar kit</button>
      </form>
    </div>
  <?php endwhile; ?>
</div>

<script>
  const toggleBtn = document.getElementById('toggle-carrito');
  const carritoModal = document.getElementById('carrito-modal');
  const cerrarBtn = document.getElementById('cerrar-carrito');

  toggleBtn.addEventListener('click', () => {
    carritoModal.classList.toggle('active');
  });

  cerrarBtn.addEventListener('click', () => {
    carritoModal.classList.remove('active');
  });

  window.addEventListener('click', (e) => {
    if (!carritoModal.contains(e.target) && !toggleBtn.contains(e.target)) {
      carritoModal.classList.remove('active');
    }
  });
</script>

</body>
</html>
