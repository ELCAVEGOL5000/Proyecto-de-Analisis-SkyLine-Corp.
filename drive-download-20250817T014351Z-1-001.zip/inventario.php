<?php
session_start();
include 'config.php';

// Chequear rol
if ($_SESSION['rol'] !== 'admin') {
    header("Location: tienda.php");
    exit;
}

// Eliminar producto
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    // Primero eliminar referencias en kit_producto para evitar error FK
    $conn->query("DELETE FROM kit_producto WHERE producto_id=$id");
    // Luego eliminar producto
    $conn->query("DELETE FROM productos WHERE id=$id");
}

// Eliminar kit
if (isset($_GET['delete_kit'])) {
    $id = intval($_GET['delete_kit']);
    $conn->query("DELETE FROM kit_producto WHERE kit_id=$id");
    $conn->query("DELETE FROM kits WHERE id=$id");
}

// Traer productos
$productos = $conn->query("SELECT * FROM productos");

// Traer kits
$kits = $conn->query("SELECT * FROM kits");

function obtenerProductosDeKit($conn, $kit_id) {
    $stmt = $conn->prepare("
        SELECT p.nombre 
        FROM kit_producto kp
        JOIN productos p ON kp.producto_id = p.id
        WHERE kp.kit_id = ?
    ");
    $stmt->bind_param("i", $kit_id);
    $stmt->execute();
    $res = $stmt->get_result();
    $nombres = [];
    while ($row = $res->fetch_assoc()) {
        $nombres[] = $row['nombre'];
    }
    return implode(', ', $nombres);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Inventario</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f8f9fa;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #343a40;
        }

        .top-bar {
            max-width: 900px;
            margin: 0 auto 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .btn-link {
            text-decoration: none;
            background-color: #007bff;
            color: white;
            padding: 8px 14px;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.2s;
        }

        .btn-link:hover {
            background-color: #0056b3;
        }

        table {
            width: 90%;
            margin: 30px auto;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }

        th {
            background-color: #343a40;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        img {
            border-radius: 5px;
        }

        .actions form {
            display: inline;
        }

        .btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            color: white;
            font-size: 14px;
            cursor: pointer;
        }

        .btn-edit {
            background-color: #28a745;
        }

        .btn-edit:hover {
            background-color: #218838;
        }

        .btn-delete {
            background-color: #dc3545;
        }

        .btn-delete:hover {
            background-color: #c82333;
        }

        @media (max-width: 768px) {
            table, thead, tbody, th, td, tr {
                display: block;
            }

            th {
                position: absolute;
                top: -9999px;
                left: -9999px;
            }

            tr {
                border: 1px solid #ccc;
                margin-bottom: 10px;
                padding: 10px;
                border-radius: 10px;
                background: white;
            }

            td {
                border: none;
                padding: 10px;
                text-align: left;
                position: relative;
            }

            td:before {
                content: attr(data-label);
                font-weight: bold;
                display: block;
                margin-bottom: 5px;
            }

            .top-bar {
                flex-direction: column;
                gap: 10px;
                text-align: center;
            }
        }
    </style>
</head>
<body>

<h1>Inventario</h1>

<div class="top-bar">
    <a href="producto_form.php" class="btn-link">➕ Agregar producto</a>
    <a href="tienda_page.php" class="btn-link">← Volver al inicio</a>
</div>

<!-- Tabla de Productos -->
<h2 style="text-align:center;">Productos individuales</h2>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Stock</th>
            <th>Precio</th>
            <th>Imagen</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $contador = 1; ?>
        <?php while($row = $productos->fetch_assoc()): ?>
            <tr>
                <td data-label="N°"><?= $contador++ ?></td>
                <td data-label="Nombre"><?= htmlspecialchars($row['nombre']) ?></td>
                <td data-label="Stock"><?= $row['stock'] ?></td>
                <td data-label="Precio">$<?= number_format($row['precio'], 2) ?></td>
                <td data-label="Imagen">
                    <?php if ($row['imagen']): ?>
                        <img src="<?= htmlspecialchars($row['imagen']) ?>" width="60">
                    <?php else: ?>
                        <em>Sin imagen</em>
                    <?php endif; ?>
                </td>
                <td data-label="Acciones" class="actions">
                    <form method="get" action="producto_form.php" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <button type="submit" class="btn btn-edit">Editar</button>
                    </form>
                    <form method="get" action="inventario.php" onsubmit="return confirm('¿Eliminar este producto?');" style="display:inline;">
                        <input type="hidden" name="delete" value="<?= $row['id'] ?>">
                        <button type="submit" class="btn btn-delete">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<!-- Botón Crear Kit entre tablas -->
<div style="width: 90%; max-width: 900px; margin: 20px auto; display: flex; justify-content: flex-start;">
    <a href="kit_form.php" class="btn-link">➕ Crear kit</a>
</div>

<!-- Tabla de Kits -->
<h2 style="text-align:center;">Kits</h2>
<table>
    <thead>
        <tr>
            <th>#</th>
            <th>Nombre del kit</th>
            <th>Precio</th>
            <th>Productos incluidos</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $contador = 1; ?>
        <?php while($kit = $kits->fetch_assoc()): ?>
            <tr>
                <td><?= $contador++ ?></td>
                <td><?= htmlspecialchars($kit['nombre']) ?></td>
                <td>$<?= number_format($kit['precio'], 2) ?></td>
                <td><?= obtenerProductosDeKit($conn, $kit['id']) ?></td>
                <td>
                    <form method="get" action="kit_form.php" style="display:inline;">
                        <input type="hidden" name="id" value="<?= $kit['id'] ?>">
                        <button type="submit" class="btn btn-edit">Editar</button>
                    </form>
                    <form method="get" action="inventario.php" onsubmit="return confirm('¿Eliminar este kit?');" style="display:inline;">
                        <input type="hidden" name="delete_kit" value="<?= $kit['id'] ?>">
                        <button type="submit" class="btn btn-delete">Eliminar</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

</body>
</html>
