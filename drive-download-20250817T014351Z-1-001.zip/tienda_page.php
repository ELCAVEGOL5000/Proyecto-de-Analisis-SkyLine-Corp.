<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.php");
    exit();
}

$nombre = $_SESSION['nombre'] ?? 'Usuario';
$rol = $_SESSION['rol'] ?? 'usuario';

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda</title>
    <link rel="stylesheet" href="tienda.css">

    <style>
    /* --- KITS: centrado y estilo de botones --- */
    .kits-container{
      display:flex;
      justify-content:center;
      align-items:center;
      gap:24px;
      flex-wrap:wrap;
      margin: 120px auto 48px; /* baja un poco para que no choque con el logout */
      padding: 0 16px;
      max-width: 900px;
    }
    .kit-btn{
      display:inline-block;
      text-decoration:none;
      text-align:center;
      padding:16px 28px;
      background:#0077cc;
      color:#fff;
      border:none;
      border-radius:14px;
      font-size:1.15rem;
      font-weight:700;
      cursor:pointer;
      box-shadow: 0 8px 18px rgba(0,0,0,.18);
      transition: transform .18s, box-shadow .18s, background .25s;
      width: min(320px, 90vw); /* tamaño consistente y responsivo */
    }
    .kit-btn:hover{
      transform: translateY(-3px);
      box-shadow: 0 12px 24px rgba(0,0,0,.22);
      background:#005fa3;
    }
    .kit-btn.secondary{
      background: #0a8dd9;
    }
    .kit-btn.secondary:hover{
      background:#086eab;
    }

    /* Si preferís que queden uno debajo del otro en pantallas chicas */
    @media (max-width: 520px){
      .kits-container{
        flex-direction:column;
      }
    }
  </style>
</head>
<body>
    <!-- Menú de navegación -->
    <nav class="navbar">
    <div class="logo icon">Sky Line <span>Corp</span></div>

    <input type="checkbox" id="menu-toggle" />
    <label for="menu-toggle" class="menu-icon">&#9776;</label>
  </nav>

  <!-- Bienvenida -->
  <div class="bienvenida">
    <h1>Bienvenido, <span><?= htmlspecialchars($_SESSION['nombre'] ?? 'Usuario'); ?></span></h1>
  </div>

  <!-- Botón cerrar sesión -->
  <div class="logout-flotante">
    <button onclick="window.location.href='logout.php'">Cerrar Sesión</button>
  </div>

  <!-- Contenedor de los botones -->
  <div class="kits-container">
    <a href="kits.php" class="kit-btn">Ver Kits</a>
    <a href="kits_personalizados.php" class="kit-btn secondary">Haz tu propio kit</a>

    <?php if ($rol === 'admin'): ?>
            <a href="inventario.php" class="kit-btn" style="background:#28a745;">Inventario</a>
        <?php endif; ?>
  </div>
</body>
</html>