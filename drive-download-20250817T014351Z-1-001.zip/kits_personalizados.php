<?php
session_start();
include 'config.php';

// Inicializar carrito si no existe
if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = [];
}

$mensaje = $_SESSION['mensaje'] ?? '';
unset($_SESSION['mensaje']);

// Agregar producto al carrito
if (isset($_GET['agregar'])) {
    $id = intval($_GET['agregar']);
    $cantidad = intval($_GET['cantidad'] ?? 1);
    if ($cantidad < 1) $cantidad = 1;

    $stmt = $conn->prepare("SELECT id, nombre, stock, imagen, precio FROM productos WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($producto = $res->fetch_assoc()) {
        if ($producto['stock'] <= 0) {
            $_SESSION['mensaje'] = "El producto '{$producto['nombre']}' no tiene stock disponible.";
        } else {
            $cantidadEnCarrito = $_SESSION['carrito'][$id]['cantidad'] ?? 0;
            $nuevaCantidad = $cantidadEnCarrito + $cantidad;
            if ($nuevaCantidad > $producto['stock']) {
                $_SESSION['mensaje'] = "No hay suficiente stock para la cantidad solicitada del producto '{$producto['nombre']}'. Stock disponible: {$producto['stock']}.";
            } else {
                $_SESSION['carrito'][$id] = [
                    'nombre' => $producto['nombre'],
                    'imagen' => $producto['imagen'],
                    'precio' => $producto['precio'],
                    'cantidad' => $nuevaCantidad
                ];
            }
        }
    }
    header("Location: kits_personalizados.php");
    exit;
}

// Eliminar producto del carrito
if (isset($_POST['eliminar'])) {
    $id = intval($_POST['eliminar']);
    if (isset($_SESSION['carrito'][$id])) {
        unset($_SESSION['carrito'][$id]);
    }
    header("Location: kits_personalizados.php");
    exit;
}

// Vaciar carrito
if (isset($_POST['vaciar'])) {
    $_SESSION['carrito'] = [];
    header("Location: kits_personalizados.php");
    exit;
}

// Obtener productos
$result = $conn->query("SELECT * FROM productos");
if (!$result) {
    die("Error en la consulta: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Arma tu kit personalizado</title>
  <link rel="stylesheet" href="kits.css" />
  <style>
    /* Botones */
    .btn-agregar {
      background: #28a745;
      color: white;
      padding: 8px 14px;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
      transition: background-color 0.2s;
    }
    .btn-agregar:hover {
      background: #218838;
    }
    .btn-eliminar {
      background: transparent;
      border: none;
      font-size: 20px;
      line-height: 1;
      color: #dc3545;
      cursor: pointer;
      font-weight: bold;
    }
    .btn-vaciar {
      background: #dc3545;
      color: white;
      border: none;
      padding: 10px;
      border-radius: 5px;
      width: 100%;
      font-weight: bold;
      cursor: pointer;
      margin-top: 10px;
      transition: background-color 0.2s;
    }
    .btn-vaciar:hover {
      background: #c82333;
    }

    /* Carrito */
    .carrito-modal {
      position: fixed;
      top: 60px;
      right: 20px;
      width: 320px;
      max-height: 400px;
      background: white;
      box-shadow: 0 0 15px rgba(0,0,0,0.3);
      border-radius: 8px;
      overflow-y: auto;
      padding: 15px;
      display: none;
      z-index: 1000;
    }
    .carrito-modal.active {
      display: block;
    }
    .carrito-item {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 12px;
      border-bottom: 1px solid #eee;
      padding-bottom: 10px;
    }
    .carrito-item img {
      width: 50px;
      height: 50px;
      object-fit: cover;
      border-radius: 4px;
    }
    .carrito-item-info p {
      margin: 0 0 4px;
      font-weight: bold;
    }
    .carrito-item-info span {
      font-size: 14px;
      color: #555;
      display: block;
    }
    .cerrar-carrito {
      margin-top: 10px;
      width: 100%;
      padding: 10px;
      border: none;
      background: #6c757d;
      color: white;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }
    .cerrar-carrito:hover {
      background: #5a6268;
    }

    /* Contenedor productos */
    .productos {
      display: flex;
      flex-wrap: wrap;
      gap: 20px;
      max-width: 900px;
      margin: 20px auto;
      justify-content: center;
    }
    .producto {
      background: white;
      border-radius: 8px;
      box-shadow: 0 0 8px rgba(0,0,0,0.1);
      padding: 15px;
      width: 200px;
      text-align: center;
    }
    .producto img {
      max-width: 100%;
      height: 120px;
      object-fit: contain;
      border-radius: 6px;
      margin-bottom: 8px;
    }
    .producto h3 {
      margin: 8px 0;
      font-size: 1.1em;
      color: #333;
    }
    .producto p {
      margin: 5px 0;
      font-weight: bold;
      color: #555;
    }

    /* Header */
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px;
      background: #f0f0f0;
      max-width: 900px;
      margin: 0 auto 10px;
      border-radius: 6px;
    }
    header a {
      background: #6c757d;
      color: #fff;
      padding: 10px 16px;
      border-radius: 6px;
      text-decoration: none;
      font-weight: bold;
    }
    header button {
      background: #007bff;
      color: #fff;
      border: none;
      padding: 10px 16px;
      border-radius: 6px;
      cursor: pointer;
      font-weight: bold;
    }
  </style>
</head>
<body>

<header>
  <a href="tienda_page.php">← Volver al inicio</a>
  <button id="toggle-carrito">
    Carrito
    <span style="background:#dc3545; border-radius:50%; padding:2px 8px; margin-left:6px;">
      <?= array_sum(array_column($_SESSION['carrito'], 'cantidad')) ?: 0 ?>
    </span>
  </button>
</header>

<?php if ($mensaje): ?>
  <p style="max-width:900px; margin: 10px auto; color:#dc3545; font-weight:bold; text-align:center;">
    <?= htmlspecialchars($mensaje) ?>
  </p>
<?php endif; ?>

<h1 style="text-align:center;">Arma tu propio kit</h1>

<div class="productos">
  <?php while ($row = $result->fetch_assoc()): ?>
    <div class="producto">
      <img src="<?= htmlspecialchars($row['imagen'] ?: 'img/no-image.png') ?>" alt="<?= htmlspecialchars($row['nombre']) ?>" />
      <h3><?= htmlspecialchars($row['nombre']) ?></h3>
      <p>Precio unitario: $<?= number_format($row['precio'], 2) ?></p>

      <?php if ($row['stock'] > 0): ?>
        <form method="get" action="" style="display:flex; gap:6px; align-items:center; justify-content:center;">
          <input type="hidden" name="agregar" value="<?= $row['id'] ?>">
          <input 
            type="number" 
            name="cantidad" 
            value="1" 
            min="1" 
            max="<?= $row['stock'] ?>" 
            style="width:60px; padding:4px; border-radius:4px; border:1px solid #ccc;"
            required
          >
          <button type="submit" class="btn-agregar">Agregar</button>
        </form>
      <?php else: ?>
        <p style="color:red; font-weight:bold;">No hay stock disponible</p>
      <?php endif; ?>
    </div>
  <?php endwhile; ?>
</div>

<!-- Carrito Modal -->
<div class="carrito-modal" id="carrito-modal">
  <h3>Tu carrito</h3>
  <?php if (!empty($_SESSION['carrito'])): ?>
    <?php $total = 0; ?>
    <?php foreach($_SESSION['carrito'] as $id => $item): 
      $subtotal = $item['precio'] * $item['cantidad'];
      $total += $subtotal;
    ?>
      <div class="carrito-item">
        <img src="<?= htmlspecialchars($item['imagen'] ?: 'img/no-image.png') ?>" alt="<?= htmlspecialchars($item['nombre']) ?>">
        <div class="carrito-item-info">
          <p><?= htmlspecialchars($item['nombre']) ?></p>
          <span>Cantidad: <?= $item['cantidad'] ?></span>
          <span>Precio unitario: $<?= number_format($item['precio'], 2) ?></span>
          <span>Subtotal: $<?= number_format($subtotal, 2) ?></span>
        </div>
        <form method="post" style="margin-left:auto;">
          <button type="submit" name="eliminar" value="<?= $id ?>" class="btn-eliminar" title="Eliminar">&times;</button>
        </form>
      </div>
    <?php endforeach; ?>
    <hr>
    <p style="font-weight:bold; text-align:right;">Total: $<?= number_format($total, 2) ?></p>

    <!-- Botón vaciar carrito -->
    <form method="post" style="margin-bottom:10px;">
      <button type="submit" name="vaciar" class="btn-vaciar">Vaciar carrito</button>
    </form>

    <!-- Botón pagar -->
    <form method="post" action="pagar1.php">
      <button type="submit" name="confirmar_pago" class="btn-agregar" style="width: 100%; font-size: 18px; padding: 12px; background:#007bff;">
        Pagar
      </button>
    </form>

  <?php else: ?>
    <p>Tu carrito está vacío.</p>
  <?php endif; ?>
  <button class="cerrar-carrito" id="cerrar-carrito">Cerrar</button>
</div>

<script>
  const toggleBtn = document.getElementById('toggle-carrito');
  const carritoModal = document.getElementById('carrito-modal');
  const cerrarBtn = document.getElementById('cerrar-carrito');

  toggleBtn.addEventListener('click', () => {
    carritoModal.classList.toggle('active');
  });

  cerrarBtn.addEventListener('click', () => {
    carritoModal.classList.remove('active');
  });

  window.addEventListener('click', (e) => {
    if (!carritoModal.contains(e.target) && e.target !== toggleBtn) {
      carritoModal.classList.remove('active');
    }
  });
</script>

</body>
</html>
