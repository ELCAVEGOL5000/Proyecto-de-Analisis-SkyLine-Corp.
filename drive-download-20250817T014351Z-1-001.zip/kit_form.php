<?php
// Inicio seguro de sesión
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include 'config.php';

// Verificar si el usuario es admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: tienda.php");
    exit;
}

// Obtener productos disponibles
$productos_result = $conn->query("SELECT * FROM productos");

// Modo edición (si se pasó un ID)
$editando = false;
$kit_nombre = "";
$kit_precio = "";
$productos_seleccionados = [];

if (isset($_GET['id'])) {
    $editando = true;
    $kit_id = intval($_GET['id']);

    $kit_res = $conn->prepare("SELECT * FROM kits WHERE id = ?");
    $kit_res->bind_param("i", $kit_id);
    $kit_res->execute();
    $kit_data = $kit_res->get_result();

    if ($kit_row = $kit_data->fetch_assoc()) {
        $kit_nombre = $kit_row['nombre'];
        $kit_precio = $kit_row['precio'];
    }

    // Productos del kit
    $kit_prods_stmt = $conn->prepare("SELECT producto_id FROM kit_producto WHERE kit_id = ?");
    $kit_prods_stmt->bind_param("i", $kit_id);
    $kit_prods_stmt->execute();
    $kit_prods_res = $kit_prods_stmt->get_result();

    while ($prod = $kit_prods_res->fetch_assoc()) {
        $productos_seleccionados[] = $prod['producto_id'];
    }
}

// Guardar kit (nuevo o edición)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre']);
    $precio = floatval($_POST['precio']);
    $productos = isset($_POST['productos']) ? $_POST['productos'] : [];

    if ($nombre === "" || $precio < 0) {
        $error = "Por favor, ingresa un nombre válido y un precio mayor o igual a 0.";
    } else {
        if ($editando) {
            // Actualizar kit
            $stmt = $conn->prepare("UPDATE kits SET nombre=?, precio=? WHERE id=?");
            $stmt->bind_param("sdi", $nombre, $precio, $kit_id);
            $stmt->execute();

            // Borrar relaciones anteriores
            $del_stmt = $conn->prepare("DELETE FROM kit_producto WHERE kit_id = ?");
            $del_stmt->bind_param("i", $kit_id);
            $del_stmt->execute();
        } else {
            // Crear nuevo kit
            $stmt = $conn->prepare("INSERT INTO kits (nombre, precio) VALUES (?, ?)");
            $stmt->bind_param("sd", $nombre, $precio);
            $stmt->execute();
            $kit_id = $stmt->insert_id;
        }

        // Insertar relaciones producto-kit
        $insert_stmt = $conn->prepare("INSERT INTO kit_producto (kit_id, producto_id) VALUES (?, ?)");
        foreach ($productos as $producto_id) {
            $producto_id = intval($producto_id);
            $insert_stmt->bind_param("ii", $kit_id, $producto_id);
            $insert_stmt->execute();
        }

        header("Location: inventario.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title><?= $editando ? 'Editar kit' : 'Crear kit' ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #343a40;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"] {
            width: 100%;
            padding: 10px;
            margin: 8px 0 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .checkbox-list {
            max-height: 200px;
            overflow-y: auto;
            border: 1px solid #ccc;
            padding: 10px;
            margin-bottom: 20px;
            background: white;
            border-radius: 4px;
        }
        .checkbox-list label {
            display: block;
            margin-bottom: 8px;
        }
        button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
        }
        button:hover {
            background-color: #218838;
        }
        a.back-link {
            display: block;
            text-align: center;
            margin-top: 15px;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<h1><?= $editando ? 'Editar kit' : 'Crear nuevo kit' ?></h1>

<?php if (!empty($error)): ?>
    <div class="error"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="post">
    <label for="nombre">Nombre del kit:</label>
    <input type="text" name="nombre" id="nombre" required value="<?= htmlspecialchars($kit_nombre) ?>">

    <label for="precio">Precio del kit:</label>
    <input type="number" name="precio" id="precio" step="0.01" required value="<?= htmlspecialchars($kit_precio) ?>">

    <label>Selecciona productos para el kit:</label>
    <div class="checkbox-list">
        <?php while($producto = $productos_result->fetch_assoc()): ?>
            <label>
                <input 
                    type="checkbox" 
                    name="productos[]" 
                    value="<?= $producto['id'] ?>"
                    <?= in_array($producto['id'], $productos_seleccionados) ? 'checked' : '' ?>
                >
                <?= htmlspecialchars($producto['nombre']) ?> ($<?= number_format($producto['precio'], 2) ?>)
            </label>
        <?php endwhile; ?>
    </div>

    <button type="submit"><?= $editando ? 'Actualizar kit' : 'Crear kit' ?></button>
</form>

<a href="inventario.php" class="back-link">← Volver al inventario</a>

</body>
</html>

<?php
$conn->close();
?>
