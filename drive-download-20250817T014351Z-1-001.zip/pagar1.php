<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'config.php'; // tu conexión $conn

// Verificar si carrito existe y no está vacío
if (!isset($_SESSION['carrito']) || empty($_SESSION['carrito'])) {
    header("Location: kits.php");
    exit;
}

$mensaje_error = "";

// Procesar "confirmar pago"
if (isset($_POST['confirmar_pago'])) {
    $errores_stock = [];

    // Validar stock antes de descontar
    foreach ($_SESSION['carrito'] as $id => $item) {
        if (isset($item['es_kit']) && $item['es_kit']) {
            // Es un kit
            $kit_id = $item['kit_id'];
            $cantidad_kit = intval($item['cantidad']);

            $stmt = $conn->prepare("
                SELECT p.id, p.nombre, p.stock, kp.cantidad as cantidad_kit_producto 
                FROM kit_producto kp
                JOIN productos p ON kp.producto_id = p.id
                WHERE kp.kit_id = ?
            ");
            $stmt->bind_param("i", $kit_id);
            $stmt->execute();
            $result = $stmt->get_result();

            while ($prod = $result->fetch_assoc()) {
                $stock_necesario = $prod['cantidad_kit_producto'] * $cantidad_kit;
                if ($prod['stock'] < $stock_necesario) {
                    $errores_stock[] = "No hay suficiente stock para el producto <strong>" . htmlspecialchars($prod['nombre']) . "</strong> en el kit <strong>" . htmlspecialchars($item['nombre']) . "</strong>";
                }
            }

        } else {
            // Producto normal
            $producto_id = intval($id);
            $cantidad = intval($item['cantidad']);

            $stmt = $conn->prepare("SELECT stock FROM productos WHERE id = ?");
            $stmt->bind_param("i", $producto_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                if ($row['stock'] < $cantidad) {
                    $errores_stock[] = "No hay suficiente stock para el producto: <strong>" . htmlspecialchars($item['nombre']) . "</strong>";
                }
            } else {
                $errores_stock[] = "Producto no encontrado: <strong>" . htmlspecialchars($item['nombre']) . "</strong>";
            }
        }
    }

    // Si no hay errores, descontar stock y vaciar carrito
    if (empty($errores_stock)) {
        foreach ($_SESSION['carrito'] as $id => $item) {
            if (isset($item['es_kit']) && $item['es_kit']) {
                $kit_id = $item['kit_id'];
                $cantidad_kit = intval($item['cantidad']);

                $stmt = $conn->prepare("
                    SELECT p.id, kp.cantidad as cantidad_kit_producto 
                    FROM kit_producto kp
                    JOIN productos p ON kp.producto_id = p.id
                    WHERE kp.kit_id = ?
                ");
                $stmt->bind_param("i", $kit_id);
                $stmt->execute();
                $result = $stmt->get_result();

                while ($prod = $result->fetch_assoc()) {
                    $stock_a_restar = $prod['cantidad_kit_producto'] * $cantidad_kit;
                    $stmt_update = $conn->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?");
                    $stmt_update->bind_param("ii", $stock_a_restar, $prod['id']);
                    $stmt_update->execute();
                }

            } else {
                $producto_id = intval($id);
                $cantidad = intval($item['cantidad']);
                $stmt = $conn->prepare("UPDATE productos SET stock = stock - ? WHERE id = ?");
                $stmt->bind_param("ii", $cantidad, $producto_id);
                $stmt->execute();
            }
        }

        $_SESSION['carrito'] = [];
        $_SESSION['mensaje_pago'] = "¡Pago realizado con éxito! Gracias por tu compra.";
        header("Location: kits_personalizados.php");
        exit;
    } else {
        $mensaje_error = implode("<br>", $errores_stock);
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <title>Confirmar Pago</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
            background: #f9f9f9;
            border-radius: 8px;
        }
        h1 {
            text-align: center;
            color: #343a40;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #343a40;
            color: white;
        }
        .btn-confirmar {
            margin-top: 20px;
            width: 100%;
            background: #28a745;
            border: none;
            padding: 14px;
            font-size: 18px;
            color: white;
            font-weight: bold;
            cursor: pointer;
            border-radius: 6px;
            transition: background-color 0.3s;
        }
        .btn-confirmar:hover {
            background: #218838;
        }
        .btn-volver {
            margin-top: 15px;
            display: block;
            text-align: center;
            text-decoration: none;
            color: #007bff;
            font-weight: bold;
        }
        .error {
            background: #ffdddd;
            border: 1px solid #ff5c5c;
            color: #a94442;
            padding: 15px;
            border-radius: 5px;
            margin-top: 15px;
        }
    </style>
</head>
<body>

<h1>Resumen de tu compra</h1>

<?php if (!empty($mensaje_error)): ?>
    <div class="error">
        <?= $mensaje_error ?>
    </div>
<?php endif; ?>

<table>
    <thead>
        <tr>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio unitario</th>
            <th>Subtotal</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $total = 0;
        foreach ($_SESSION['carrito'] as $item): 
            $subtotal = $item['precio'] * $item['cantidad'];
            $total += $subtotal;
        ?>
            <tr>
                <td><?= htmlspecialchars($item['nombre']) ?></td>
                <td><?= $item['cantidad'] ?></td>
                <td>$<?= number_format($item['precio'], 2) ?></td>
                <td>$<?= number_format($subtotal, 2) ?></td>
            </tr>
        <?php endforeach; ?>
        <tr>
            <th colspan="3" style="text-align:right;">Total</th>
            <th>$<?= number_format($total, 2) ?></th>
        </tr>
    </tbody>
</table>

<form method="post">
    <button type="submit" name="confirmar_pago" class="btn-confirmar">Confirmar Pago</button>
</form>

<a href="kits_personalizados.php" class="btn-volver">← Volver a la tienda</a>

</body>
</html>
